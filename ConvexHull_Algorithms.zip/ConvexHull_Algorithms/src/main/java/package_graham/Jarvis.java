/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package package_graham;

/**
 *
 * @author Koala
 */
/**
 ** Java Program to Implement Jarvis Algorithm
 **/
 
import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;
/** Class point **/
class Point
{
    int x, y;
}
 
/** Class Jarvis **/
public class Jarvis
{    
    private boolean CCW(Point p, Point q, Point r)
    {
        int val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
 
         if (val >= 0)
             return false;
         return true;
    }
    public void convexHull(Point[] points)
    {
        int n = points.length;
        /** if less than 3 points return **/        
        if (n < 3) 
            return;     
        int[] next = new int[n];
        Arrays.fill(next, -1);
 
        /** find the leftmost point **/
        int leftMost = 0;
        for (int i = 1; i < n; i++)
            if (points[i].x < points[leftMost].x)
                leftMost = i;
        int p = leftMost, q;
        /** iterate till p becomes leftMost **/
        do
        {
            /** wrapping **/
            q = (p + 1) % n;
            for (int i = 0; i < n; i++)
              if (CCW(points[p], points[i], points[q]))
                 q = i;
 
            next[p] = q;  
            p = q; 
        } while (p != leftMost);
 
        /** Display result **/
        display(points, next);
    }
    public void display(Point[] points, int[] next)
    {
      
        for (int i = 0; i < next.length; i++)
            if (next[i] != -1)
               System.out.println("("+ points[i].x +", "+ points[i].y +")");
    }
    /** Main function **/
    public static void main (String[] args) throws InterruptedException
    {
        long inicio = System.nanoTime();
		
        Scanner scan = new Scanner(System.in);
        System.out.println("Jarvis Algorithm Test\n");
        /** Make an object of Jarvis class **/
                         
        System.out.println("Enter number of points n :");
        int n = scan.nextInt();
        Jarvis j = new Jarvis(); 
        Point[] points = new Point[n];
        System.out.println("Enter "+ n +" x, y cordinates");
        for (int i = 0; i < n; i++)
        {
            points[i] = new Point();
            points[i].x = scan.nextInt();
            points[i].y = scan.nextInt();
        }        
        
        System.out.println("El convex hull consiste en el seguimiento de los siguientes puntos: ");
        j.convexHull(points);
	//Thread.sleep(3000);
     
        long fin = (System.nanoTime()-inicio)/1000000;
        System.out.println("El programa dura " + fin + " ms");
        
    }
}
/*

int n = 20;
        Point[] points = new Point[n];
        points[0] = new Point();
        points[1] = new Point();
        points[2] = new Point();
        points[3] = new Point();
        points[4] = new Point();
        points[5] = new Point();
        points[6] = new Point();
        points[7] = new Point();
        points[8] = new Point();
        points[9] = new Point();
        points[10] = new Point();
        points[11] = new Point();
        points[12] = new Point();
        points[13] = new Point();
        points[14] = new Point();
        points[15] = new Point();
        points[16] = new Point();
        points[17] = new Point();
        points[18] = new Point();
        points[19] = new Point();

        points[0].x = 3;  
        points[0].y = 4;  
        points[1].x = 1;  
        points[1].y = 5;  
        points[2].x = 2;  
        points[2].y = 2;  
        points[3].x = 3;  
        points[3].y = 3;  
        points[4].x = 8;  
        points[4].y = 9;  
        points[5].x = 1;  
        points[5].y = 6;  
        points[6].x = 4;  
        points[6].y = 3;  
        points[7].x = 9;  
        points[7].y = 5;  
        points[8].x = 1;  
        points[8].y = 9;  
        points[9].x = 2;  
        points[9].y = 7 ; 
        points[10].x = 6;  
        points[10].y = 4;  
        points[11].x = 4;  
        points[11].y = 1;  
        points[12].x = 5;  
        points[12].y = 5;  
        points[13].x = 7;  
        points[13].y = 8;  
        points[14].x = 6;  
        points[14].y = 1;  
        points[15].x = 7;  
        points[15].y = 4;  
        points[16].x = 5;  
        points[16].y = 9;  
        points[17].x = 2;  
        points[17].y = 8;  
        points[18].x = 6;  
        points[18].y = 8;  
        points[19].x = 7;  
        points[19].y = 1;    




        /* (0, 3)
    (3, 5)
    (5, 3)
    (3, 0)
    (1, 1)
        Enter number of points n :
8
Enter 8 x, y cordinates
0 3
4 2
3 5
5 3
3 0
1 1
1 2
2 2
        intento 1:  15.976357 s
        intento 2:  12.233552600000001 s
        intento 3:  12.233552600000001 s
        
        
        intento de resta 1 :  6.640 - 5.570  = 1.07
        intento de resta 2 :  17.713 - 16673  = 1.04
        intento de resta 2 :  17.615 - 16563  = 1.052       11.953 - 10867 = 1.086
        
        
        (1, 5)          
        (2, 2)
        (8, 9)
        (9, 5)
        (1, 9)
        (4, 1)
        (6, 1)
        (7, 1)
        
(4.0, 1.0)
(7.0, 1.0)
(9.0, 5.0)
(8.0, 9.0)
(1.0, 9.0)
(1.0, 5.0)
(2.0, 2.0)
        */
        